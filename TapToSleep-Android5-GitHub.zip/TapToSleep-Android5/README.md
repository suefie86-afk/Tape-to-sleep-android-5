# Tap to Sleep (Android 5.0+)

Aplikasi Android Java ringkas: tekan ikon **Tap to Sleep** pada launcher untuk kunci skrin. Kali pertama, benarkan **Device Administrator** (polisi **force-lock** sahaja). Selepas itu, setiap kali tekan ikon, skrin dikunci terus.

## Bina APK menggunakan GitHub (tanpa extract ZIP di telefon)
1. Cipta repository kosong di GitHub.
2. Dalam repository, klik **Add file > Upload files** dan pilih **ZIP**? GitHub **tidak** mengekstrak ZIP secara automatik. Untuk menggunakan fail ZIP tanpa extract, gunakan GitHub Codespaces: buka Codespace, upload ZIP, kemudian jalankan `unzip TapToSleep-Android5-GitHub.zip -d .` (ini extract dalam cloud, bukan telefon), `git add . && git commit -m "Add Android app" && git push`.
3. Buka tab **Actions > Build Tap to Sleep APK > Run workflow**.
4. Muat turun artifact `TapToSleep-Android5-APK` (ZIP yang mengandungi `app-debug.apk`), extract artifact dan pasang APK.

Alternatif: extract ZIP projek pada telefon/PC dan upload **semua kandungan** (termasuk folder `.github`) ke root repo, bukan fail ZIP sahaja.

## Nota
- Minimum Android 5.0 (API 21). Android 5.1.1 disokong.
- `DevicePolicyManager.lockNow()` memerlukan Device Administrator. Untuk uninstall, matikan Device Administrator untuk aplikasi ini dalam Settings > Security dahulu.
- Ini fungsi **tap ikon untuk lock**, bukan double-tap pada ruang kosong home screen; double-tap memerlukan sokongan launcher atau accessibility service.
- Debug APK ditandatangani automatik oleh Android build tools untuk ujian, bukan release production.
